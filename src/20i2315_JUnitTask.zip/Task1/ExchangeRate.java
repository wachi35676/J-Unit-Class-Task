package Task1;

public class ExchangeRate {
    static final double USD = 1.0;
    static final double GBP = 1.487;
    static final double FRF = 0.172;
    static final double DEM = 0.584;
    static final double JPY = 0.00955;
}
